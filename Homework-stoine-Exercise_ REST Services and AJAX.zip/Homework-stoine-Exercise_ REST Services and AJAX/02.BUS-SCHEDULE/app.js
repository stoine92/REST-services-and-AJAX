function solve() {
    let startUrl = `https://judgetests.firebaseio.com/schedule/`
    let busStopId = 'depot';
    let busStopName;
    let infoElement = document.getElementById('info');
    

    function depart() {
        const urlEnd = `${startUrl}${busStopId}.json`;
        fetch(urlEnd)
        .then(line => line.json())
        .then(data =>{
            infoElement.textContent = `Next stop ${data.name}`
            busStopId = data.next;
            busStopName = data.name;
        })
        .catch(() => {
            infoElement.textContent = "Error"
            let depBtn = document.getElementById('depart');
            let arrvieBtn = document.getElementById('arrive');
            depBtn.disabled = true;
            arrvieBtn.disabled = true;

        })
        buttonSwap();
    }

    function arrive() {
        infoElement.textContent = `Arriving at ${busStopName}`;
        buttonSwap()
    }


    function buttonSwap(){
        let depBtn = document.getElementById('depart');
        let arrvieBtn = document.getElementById('arrive');

        if(depBtn.disabled){
            depBtn.disabled = false;
            arrvieBtn.disabled = true;
        }else{
            depBtn.disabled = true;
            arrvieBtn.disabled = false;
        }
    }

    return {
        depart,
        arrive
    };
}

let result = solve();