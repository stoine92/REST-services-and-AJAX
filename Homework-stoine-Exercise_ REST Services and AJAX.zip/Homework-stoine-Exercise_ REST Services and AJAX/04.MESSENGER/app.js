function attachEvents() {
    let url = `https://rest-messanger.firebaseio.com/messanger.json`;
    let refresh = document.getElementById('refresh');
    refresh.addEventListener('click', () => {
        fetch(url)
        .then(line => line.json())
        .then((data) => {
            let getResult = Object.values(data).reduce((acc, curr) => 
            (acc += `${curr.author}: ${curr.content}\n`),"");

            document.getElementById('messages').textContent = getResult;
        })
    })

    let submitBtn = document.getElementById('submit');
    submitBtn.addEventListener('click', () => {
        let author = document.getElementById('author')
        let content = document.getElementById('content')
        fetch(url, {
            method: 'POST',
            body: JSON.stringify({
                author: author.value,
                content: content.value,
            
            })
        })
        author.value = ""
        content.value = ""
    })
}

attachEvents();