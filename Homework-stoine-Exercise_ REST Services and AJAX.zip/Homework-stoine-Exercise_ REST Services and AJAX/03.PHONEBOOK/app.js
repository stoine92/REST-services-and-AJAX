function attachEvents() {
    const url = "https://phonebook-nakov.firebaseio.com/phonebook.json";
   
    let loadTheBtn = document.getElementById("btnLoad");
    let createBtn = document.getElementById("btnCreate");
    let ul = document.getElementById("phonebook");
   
    loadTheBtn.addEventListener("click", () => {
      fetch(url)
        .then((line) => line.json())
        .then((data) => {
          Object.keys(data).forEach((key) => {
            let li = document.createElement("li");
            li.textContent = `${data[key].person}: ${data[key].phone}`;
            let deleting = document.createElement("button");
   
            deleting.textContent = "Delete";
            deleting.addEventListener("click", () => {delButton(key)});
   
            li.appendChild(deleting);
   
            ul.appendChild(li);
          });
        });
    });
   
    createBtn.addEventListener("click", creating);
   
    function delButton(key) {
      let secondUrl = `https://phonebook-nakov.firebaseio.com/phonebook/${key}.json`;
      fetch(secondUrl, { method: "DELETE" });
    }
   
    function creating() {
      let personName = document.getElementById("person");
      let phoneNum = document.getElementById("phone");
   
      fetch(url, {
        method: "POST",
        body: JSON.stringify({ person: personName.value, phone: phoneNum.value })
      });
    }
  }
   
  attachEvents();